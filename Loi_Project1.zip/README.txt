Ryan Loi
10/27/16

Best if played with the terminal at 80x31 pixels

This game is Battleship!
There are two players and later to be implemented a mode to play against a computer of a difficulty that the user enters.
Since there is only a two player mode right now the game goes like this...
Both players have 5 ships and must place their ships on their 10x10 board.
The axis' are labeled and the players must enter in the coordinates of where they'd like to place the beginning of their ship.
Once the player has decided where the beginning of their ship will be placed they will the pick which direction the rest of the ship will go.
The game makes sure that no ship is placed on top of another and that all of the ship is placed within the coordinate system. 

After both players have created their boards that game begins!
The game will notify which players turn it is and when it's your turn you'll see two boards.
I'm gonna assume you know what battleship and give a brief explanation of what's shown. 
One board on top that is the enemies board as a concealed version (doesn't show the ships) and one board on the bottom that 
you board. The player must enter in a target on the enemies board, but targets will show up on both boards and "M"s and "X"s.
X's are hits and M's are misses.

Once a player loses all their ships they have lost!
The winner gets to choose if they'd like to enter their name into a list of winners file.

Steps:
1) Each player must place their ships on their boards
2) After the boards are finished the actual game will begin
3) Each round the specified player must input coordinates of where they'd like to attack on the enemies board
4) If the target is a "hit" it will get marked as a "X" and the game will tell you that you got a hit
5) If the target is a "miss" it will get marked as a "M" and the game will tell you that you missed
6) Once a player destroys all of the other players ships before all theirs die, he/she wins
7) Winner is asked if they want to enter their name into a document of winners

Screenshots:


Thanks for playing!